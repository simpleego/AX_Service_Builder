# 이 폴더를 Python 패키지로 선언한다.
# 모듈 import 시점에 os.getenv를 읽는 코드(security.py, oauth.py)가 있으므로 가장 먼저 .env를 로드한다.
from dotenv import load_dotenv
load_dotenv()
