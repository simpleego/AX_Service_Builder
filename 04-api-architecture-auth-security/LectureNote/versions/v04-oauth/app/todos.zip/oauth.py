"""Google 소셜 로그인(OAuth 2.0 + OpenID Connect) 라우터.

전체 흐름
    1. GET  /api/auth/google            : state·nonce·PKCE를 만들고 Google 로그인 화면으로 보낸다.
    2. (사용자가 Google에서 계정 선택·동의)
    3. GET  /api/auth/google/callback   : Google이 돌려준 인가 코드를 검증·교환하고 앱 사용자를 찾거나 만든다.
         - 기본(Postman/브라우저 직접): 앱 토큰(JSON)을 바로 응답한다.
         - client=web(React): 60초 일회용 코드만 붙여 React 앱으로 리다이렉트한다.
    4. POST /api/auth/google/exchange   : React가 일회용 코드를 앱 토큰(access + refresh)으로 바꾼다.

보안 장치 요약
    - state + oauth_binding 쿠키 : 로그인 CSRF 방지 (다른 브라우저가 시작한 로그인 결과를 받지 않음)
    - nonce                      : ID 토큰 재사용(replay) 방지
    - PKCE(S256)                 : 인가 코드를 가로채도 verifier 없이는 토큰으로 바꿀 수 없음
    - provider + sub로 식별       : 이메일이 같다는 이유만으로 기존 계정에 자동 연결하지 않음
"""
import os, secrets, base64, hashlib, logging
from datetime import timedelta
from urllib.parse import urlencode
from typing import Annotated
import httpx
from google.oauth2 import id_token
from google.auth.transport.requests import Request as GoogleRequest
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse, JSONResponse
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import select
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from .database import get_db
from .models import OAuthState, SocialAccount, User, LoginHandoff
from .security import now, digest, issue_tokens
from .auth import TokenPair
router = APIRouter(prefix='/api/auth/google', tags=['Google OIDC'])
DB = Annotated[Session, Depends(get_db)]
# Google 콘솔의 "승인된 리디렉션 URI"와 글자 하나까지 같아야 한다(localhost / 127.0.0.1 혼용 금지).
CALLBACK = os.getenv('GOOGLE_REDIRECT_URI', 'http://localhost:8000/api/auth/google/callback')
# React 프런트엔드 주소. client=web으로 시작한 로그인은 callback 후 이 주소로 돌려보낸다.
FRONTEND_URL = os.getenv('FRONTEND_URL', '').rstrip('/')
# 로그인용 쿠키는 이 경로 아래 요청(시작·콜백)에만 전송되도록 범위를 좁힌다.
COOKIE_PATH = '/api/auth/google'


def settings():
    """.env에서 Google 클라이언트 ID/Secret을 읽는다.

    값이 없으면 로그인을 진행할 수 없으므로 503 OAUTH_NOT_CONFIGURED를 낸다.
    반환: (client_id, client_secret)
    """
    client_id, secret = os.getenv('GOOGLE_CLIENT_ID'), os.getenv('GOOGLE_CLIENT_SECRET')
    if not client_id or not secret:
        raise HTTPException(503, 'OAUTH_NOT_CONFIGURED')
    return client_id, secret


def cookie_options():
    """로그인 과정에서 쓰는 임시 쿠키(oauth_binding, oauth_return)의 공통 옵션.

    - httponly : JavaScript에서 읽을 수 없게 해 XSS로 값을 빼가지 못하게 한다.
    - samesite=lax : Google에서 돌아오는 최상위 GET 리다이렉트에는 쿠키가 실리고,
                     다른 사이트의 POST·iframe 요청에는 실리지 않는다.
    - secure : 운영(APP_ENV=production)에서는 HTTPS에서만 전송한다.
    """
    return {'httponly': True, 'samesite': 'lax', 'secure': os.getenv('APP_ENV') == 'production', 'path': COOKIE_PATH}


@router.get('', summary='브라우저에서 Google 로그인 시작', responses={302: {'description': 'Google로 이동'}})
def google_start(db: DB, client: str = ''):
    """[1단계] Google 로그인 화면으로 리다이렉트한다.

    client=web이면 로그인 완료 후 React 앱으로 일회용 코드를 전달한다. 생략하면 기존처럼 JSON 응답.

    하는 일
        1. 무작위 값 4개를 만든다.
           - state    : Google에 보냈다가 콜백에서 그대로 돌려받는 값 (요청-응답 짝 맞추기)
           - nonce    : ID 토큰 안에 담겨 돌아오는 값 (토큰 재사용 방지)
           - verifier : PKCE 원문. 서버 DB에만 두고 Google에는 해시(challenge)만 보낸다.
           - binding  : 이 브라우저에만 HttpOnly 쿠키로 심는 값 (state를 이 브라우저에 묶음)
        2. state·binding은 해시로, nonce·verifier는 원문으로 oauth_states에 10분 유효로 저장한다.
        3. Google 인가 URL로 302 리다이렉트하면서 oauth_binding 쿠키(10분)를 심는다.
        4. React에서 시작했으면 oauth_return=web 쿠키로 "끝나면 React로 보내라"는 표시를 남긴다.
    """
    client_id, _ = settings()
    state, nonce, verifier, binding = [secrets.token_urlsafe(32) for _ in range(4)]
    # 서버 state와 브라우저 HttpOnly 쿠키를 함께 검증해 로그인 CSRF를 차단한다.
    db.add(OAuthState(state_hash=digest(state), binding_hash=digest(binding), nonce=nonce,
        verifier=verifier, expires_at=now()+timedelta(minutes=10)))
    db.commit()
    # PKCE S256: challenge = BASE64URL(SHA256(verifier)), 끝의 '=' 패딩 제거.
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b'=').decode()
    # scope 'openid'가 있어야 Google이 ID 토큰을 준다. email/profile은 이메일·이름 클레임용.
    params = {'client_id': client_id, 'redirect_uri': CALLBACK, 'response_type': 'code',
        'scope': 'openid email profile', 'state': state, 'nonce': nonce,
        'code_challenge': challenge, 'code_challenge_method': 'S256'}
    response = RedirectResponse('https://accounts.google.com/o/oauth2/v2/auth?' + urlencode(params), status_code=302)
    response.set_cookie('oauth_binding', binding, max_age=600, **cookie_options())
    if client == 'web' and FRONTEND_URL:
        response.set_cookie('oauth_return', 'web', max_age=600, **cookie_options())
    else:
        # 이전에 React로 시작했다가 남은 표시가 있으면 지워 JSON 모드로 동작하게 한다.
        response.delete_cookie('oauth_return', path=COOKIE_PATH)
    return response


def authenticate_google(request: Request, db: Session, state: str, code: str, error: str) -> int:
    """[2단계 핵심] 콜백 파라미터를 검증하고 로그인할 앱 사용자 id를 돌려준다.

    state/쿠키/PKCE/ID Token을 검증하고 앱 사용자 id를 돌려준다. 실패 시 HTTPException.
    응답 형태(JSON / React 리다이렉트)와 무관한 검증 로직만 모아 두어 두 경로가 함께 쓴다.

    검증 순서와 실패 코드
        1. state + oauth_binding 쿠키가 DB의 유효한 레코드와 맞는지   → 400 INVALID_STATE
        2. 레코드를 즉시 삭제해 같은 state를 두 번 못 쓰게 한다(일회성).
        3. 사용자가 동의를 거부했거나(error) code가 없는지          → 400 OAUTH_DENIED
        4. code + verifier로 Google 토큰 엔드포인트에서 ID 토큰 교환
        5. ID 토큰 서명·발급자·대상(aud)·만료와 nonce·sub 확인       → 401 OAUTH_FAILED
    사용자 매핑
        - social_accounts에서 (provider='google', provider_subject=sub)를 찾는다.
        - 없으면 비밀번호 없는 users 행 + social_accounts 행을 새로 만든다(소셜 회원가입).
        - 있으면 표시용 provider_email만 최신 값으로 갱신한다.
    """
    client_id, secret = settings()
    binding = request.cookies.get('oauth_binding', '')
    # FOR UPDATE로 잠가서 같은 콜백이 동시에 두 번 와도 한 번만 통과하게 한다.
    record = db.scalar(select(OAuthState).where(OAuthState.state_hash == digest(state),
        OAuthState.binding_hash == digest(binding), OAuthState.expires_at > now()).with_for_update())
    if not state or not binding or record is None:
        raise HTTPException(400, 'INVALID_STATE')
    nonce, verifier = record.nonce, record.verifier
    db.delete(record)
    db.commit()  # 외부 네트워크 요청 전에 일회성 state 소비를 확정한다.
    if error or not code:
        raise HTTPException(400, 'OAUTH_DENIED')
    try:
        # PKCE verifier는 브라우저에 노출하지 않고 서버에서만 사용한다.
        result = httpx.post('https://oauth2.googleapis.com/token', data={
            'client_id': client_id, 'client_secret': secret, 'code': code, 'code_verifier': verifier,
            'grant_type': 'authorization_code', 'redirect_uri': CALLBACK}, timeout=10)
        result.raise_for_status()
        # PC 시계가 Google보다 조금 늦으면 iat가 미래로 보여 거부된다. 10초 오차를 허용한다.
        profile = id_token.verify_oauth2_token(result.json()['id_token'], GoogleRequest(), client_id,
            clock_skew_in_seconds=10)
        # Google 라이브러리가 서명/issuer/audience/exp를 검증한다. nonce는 직접 비교한다.
        if profile.get('nonce') != nonce or not profile.get('sub'):
            raise ValueError('invalid nonce/sub')
    except Exception as exc:
        # 실패 원인만 서버 로그에 남긴다. 토큰·코드 원문은 기록하지 않는다.
        detail = exc.response.text[:300] if isinstance(exc, httpx.HTTPStatusError) else str(exc)[:300]
        logging.getLogger('uvicorn.error').warning('OAUTH_FAILED %s: %s', type(exc).__name__, detail)
        raise HTTPException(401, 'OAUTH_FAILED')
    # sub: Google 계정마다 바뀌지 않는 고유 ID. 이메일은 바뀔 수 있으므로 식별자로 쓰지 않는다.
    subject = profile['sub']
    # Google이 소유를 확인한 이메일만 저장한다(표시용).
    email = profile.get('email') if profile.get('email_verified') else None
    account = db.scalar(select(SocialAccount).where(SocialAccount.provider == 'google', SocialAccount.provider_subject == subject))
    if account is None:
        # 이메일 일치만으로 로컬 계정에 자동 연결하지 않는다. provider + sub가 외부 신원이다.
        user = User(email=None, password_hash=None)
        db.add(user)
        db.flush()  # INSERT를 먼저 보내 user.id를 받아 온다(커밋은 아직).
        account = SocialAccount(provider='google', provider_subject=subject, user_id=user.id, provider_email=email)
        db.add(account)
        try:
            db.commit()
        except IntegrityError:
            # 동시 최초 로그인은 UNIQUE 제약으로 중복 생성을 막고 기존 연결을 읽는다.
            db.rollback()
            account = db.scalar(select(SocialAccount).where(SocialAccount.provider == 'google', SocialAccount.provider_subject == subject))
            if account is None:
                raise
    elif email and account.provider_email != email:
        # 표시용 이메일만 최신으로 맞춘다. 식별은 여전히 provider + sub.
        account.provider_email = email
        db.commit()
    return account.user_id


@router.get('/callback', response_model=TokenPair, summary='Google 인가 코드 교환 및 앱 JWT 발급',
    responses={302: {'description': 'client=web 로그인이면 React 앱으로 일회용 코드와 함께 이동'}})
def google_callback(request: Request, db: DB, state: str = '', code: str = '', error: str = ''):
    """[2단계] Google이 사용자를 돌려보내는 주소(redirect_uri).

    authenticate_google()로 검증·사용자 매핑을 한 뒤, 시작할 때 남긴 oauth_return 쿠키에 따라 응답한다.
        - JSON 모드  : 앱 토큰(access 15분 + refresh 7일)을 바로 JSON으로 돌려준다.
                       실패하면 HTTPException이 그대로 4xx JSON 응답이 된다.
        - React 모드 : 토큰 대신 60초 일회용 코드를 만들어 FRONTEND_URL/auth/callback?code=... 로 보낸다.
                       실패하면 ?error=오류코드 로 보내 React 화면이 메시지를 띄우게 한다.
    어느 경우든 마지막에 로그인용 임시 쿠키 두 개를 지운다.
    """
    to_web = request.cookies.get('oauth_return') == 'web' and bool(FRONTEND_URL)
    if not to_web:
        # 프런트 없는 수업용 JSON 응답(Postman/브라우저 직접 확인용).
        user_id = authenticate_google(request, db, state, code, error)
        tokens = issue_tokens(db, user_id)
        db.commit()
        response = JSONResponse(tokens)
    else:
        try:
            user_id = authenticate_google(request, db, state, code, error)
        except HTTPException as exc:
            response = RedirectResponse(f'{FRONTEND_URL}/auth/callback?' + urlencode({'error': exc.detail}), status_code=302)
        else:
            # 토큰을 URL에 넣지 않는다. 60초짜리 일회용 코드만 전달하고, React가 POST로 토큰과 교환한다.
            # (URL은 브라우저 기록·Referer·서버 로그에 남을 수 있기 때문)
            handoff = secrets.token_urlsafe(32)
            db.add(LoginHandoff(code_hash=digest(handoff), user_id=user_id, expires_at=now()+timedelta(seconds=60)))
            db.commit()
            response = RedirectResponse(f'{FRONTEND_URL}/auth/callback?' + urlencode({'code': handoff}), status_code=302)
    response.delete_cookie('oauth_binding', path=COOKIE_PATH)
    response.delete_cookie('oauth_return', path=COOKIE_PATH)
    return response


class HandoffInput(BaseModel):
    """POST /exchange 요청 본문. code는 token_urlsafe(32)가 만드는 43자 형식만 받는다."""
    model_config = ConfigDict(extra='forbid')
    code: str = Field(pattern=r'^[A-Za-z0-9_-]{43}$')


@router.post('/exchange', response_model=TokenPair, summary='React 앱: 일회용 코드를 앱 토큰으로 교환')
def google_exchange(data: HandoffInput, db: DB):
    """[3단계, React 전용] 콜백에서 받은 일회용 코드를 앱 토큰으로 바꾼다.

    - DB에는 코드의 SHA-256 해시만 있으므로 받은 코드를 해시해서 찾는다.
    - 없거나 60초가 지났으면 400 INVALID_HANDOFF (만료된 레코드는 이때 정리).
    - 성공하면 레코드를 지워 같은 코드를 다시 쓸 수 없게 하고, 일반 로그인과 같은 토큰 쌍을 발급한다.
    """
    # FOR UPDATE로 잠가 같은 코드로 동시에 두 번 교환하는 것을 막는다.
    record = db.scalar(select(LoginHandoff).where(LoginHandoff.code_hash == digest(data.code)).with_for_update())
    if record is None or record.expires_at <= now():
        if record is not None:
            db.delete(record)
            db.commit()
        raise HTTPException(400, 'INVALID_HANDOFF')
    user_id = record.user_id
    db.delete(record)  # 한 번 사용하면 즉시 삭제한다.
    tokens = issue_tokens(db, user_id)
    db.commit()  # 코드 삭제와 refresh 토큰 저장을 한 트랜잭션으로 확정한다.
    return tokens
