from datetime import datetime
from sqlalchemy import String, Integer, Boolean, DateTime, ForeignKey, text, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
class Base(DeclarativeBase):
    pass
class User(Base):
    # 앱 회원. 로컬 회원은 email/password_hash가 있고, Google로만 가입한 회원은 둘 다 NULL이다.
    __tablename__ = 'users'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str | None] = mapped_column(String(254), unique=True)
    password_hash: Mapped[str | None] = mapped_column(String(200))
    # 인가 역할. 'user'(기본) 또는 'admin'. 관리자 API는 require_role('admin')으로 이 값을 확인한다.
    role: Mapped[str] = mapped_column(String(20), default='user', server_default='user')
class Todo(Base):
    __tablename__ = 'todos'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    owner_id: Mapped[int] = mapped_column(ForeignKey('users.id'))
    title: Mapped[str] = mapped_column(String(200))
    completed: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'))
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=text('CURRENT_TIMESTAMP'), server_onupdate=text('CURRENT_TIMESTAMP'))
class RefreshToken(Base):
    __tablename__ = 'refresh_tokens'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'))
    family_id: Mapped[str] = mapped_column(String(36))
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime)
class SocialAccount(Base):
    # 외부 로그인 신원과 앱 회원의 연결. (provider, provider_subject)가 UNIQUE라
    # 같은 Google 계정(sub)은 항상 같은 회원 하나로만 로그인된다. 한 회원이 여러 제공자를 가질 수 있다.
    # provider_email은 표시용이며 식별에는 쓰지 않는다.
    __tablename__ = 'social_accounts'
    __table_args__ = (UniqueConstraint('provider', 'provider_subject'),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    provider: Mapped[str] = mapped_column(String(30))
    provider_subject: Mapped[str] = mapped_column(String(255))
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'))
    provider_email: Mapped[str | None] = mapped_column(String(254))
class OAuthState(Base):
    # 진행 중인 소셜 로그인 1건(10분 유효). 시작 때 저장하고 콜백에서 확인 즉시 삭제한다(일회성).
    # state/binding은 해시로, nonce/verifier는 콜백에서 원문이 필요하므로 그대로 저장한다.
    __tablename__ = 'oauth_states'
    state_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    binding_hash: Mapped[str] = mapped_column(String(64))
    nonce: Mapped[str] = mapped_column(String(64))
    verifier: Mapped[str] = mapped_column(String(128))
    expires_at: Mapped[datetime] = mapped_column(DateTime)
class LoginHandoff(Base):
    # Google 로그인 후 React 앱에 넘기는 60초 일회용 코드. 원문은 저장하지 않는다.
    __tablename__ = 'login_handoffs'
    code_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'))
    expires_at: Mapped[datetime] = mapped_column(DateTime)
# 테이블 생성은 database/01-schema.sql을 기준으로 한다. 앱이 DDL 권한을 갖지 않도록 create_all은 호출하지 않는다.
