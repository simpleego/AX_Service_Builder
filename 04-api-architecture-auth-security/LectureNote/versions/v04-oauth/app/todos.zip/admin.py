"""관리자 전용 API (역할 기반 인가, RBAC).

모든 엔드포인트가 require_role('admin')을 거친다.
    - 토큰 없음/잘못됨 → 401 UNAUTHORIZED (인증 실패)
    - 일반 회원(user)  → 403 FORBIDDEN    (인가 실패)
첫 관리자는 DB에서 직접 지정한다(database/02-add-role.sql 참고).
"""
from typing import Annotated, Literal
from fastapi import APIRouter, Depends, HTTPException, Path, Query
from pydantic import BaseModel, ConfigDict
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from .database import get_db
from .models import User, SocialAccount
from .security import require_role
from .auth import Identity

# 라우터 전체에 관리자 검사를 건다. 아래 함수에서 admin_id가 필요할 때만 다시 받는다.
# 같은 함수 객체를 쓰므로 FastAPI가 요청당 한 번만 실행(캐시)한다.
admin_only = require_role('admin')
router = APIRouter(prefix='/api/admin', tags=['Admin (인가)'], dependencies=[Depends(admin_only)])
DB = Annotated[Session, Depends(get_db)]
AdminId = Annotated[int, Depends(admin_only)]
UserId = Annotated[int, Path(gt=0, le=4294967295)]


class AdminUserOut(BaseModel):
    id: int
    email: str | None
    role: str
    hasPassword: bool
    identities: list[Identity]


class AdminUserPage(BaseModel):
    items: list[AdminUserOut]
    page: int
    limit: int
    total: int


class RoleInput(BaseModel):
    """역할 변경 요청 본문. 정해진 값 외에는 422로 거부한다."""
    model_config = ConfigDict(extra='forbid')
    role: Literal['user', 'admin']


def to_out(user: User, accounts: list[SocialAccount]) -> dict:
    """users 행과 그 회원의 social_accounts 행들을 응답 형태로 합친다."""
    return {'id': user.id, 'email': user.email, 'role': user.role,
        'hasPassword': user.password_hash is not None,
        'identities': [{'provider': a.provider, 'email': a.provider_email} for a in accounts]}


@router.get('/users', response_model=AdminUserPage, summary='[관리자] 전체 회원 목록')
def list_users(db: DB, page: int = Query(1, ge=1, le=1000000), limit: int = Query(20, ge=1, le=100),
               role: Literal['user', 'admin'] | None = None):
    """전체 회원을 id 순으로 보여 준다. role로 걸러 볼 수 있다.

    로컬 회원과 Google 회원이 함께 나오며, identities로 어떤 소셜 계정이 연결됐는지 알 수 있다.
    """
    query = select(User)
    if role is not None:
        query = query.where(User.role == role)
    total = db.scalar(select(func.count()).select_from(query.subquery()))
    users = db.scalars(query.order_by(User.id).offset((page - 1) * limit).limit(limit)).all()
    # 소셜 계정을 회원별로 한 번에 읽어 N+1 조회를 피한다.
    accounts: dict[int, list[SocialAccount]] = {}
    if users:
        rows = db.scalars(select(SocialAccount).where(SocialAccount.user_id.in_([u.id for u in users]))).all()
        for a in rows:
            accounts.setdefault(a.user_id, []).append(a)
    return {'items': [to_out(u, accounts.get(u.id, [])) for u in users], 'page': page, 'limit': limit, 'total': total}


@router.patch('/users/{user_id}/role', response_model=AdminUserOut, summary='[관리자] 회원 역할 변경')
def change_role(user_id: UserId, data: RoleInput, db: DB, admin_id: AdminId):
    """회원의 역할을 user ↔ admin으로 바꾼다.

    - 대상 회원이 없으면 404 USER_NOT_FOUND
    - 자기 자신의 역할은 바꿀 수 없다(409 CANNOT_CHANGE_OWN_ROLE).
      실수로 마지막 관리자가 스스로 권한을 내려놓아 아무도 관리자가 아니게 되는 일을 막는다.
    역할은 요청마다 DB에서 읽으므로, 변경은 그 회원이 이미 가진 토큰에도 즉시 적용된다.
    """
    if user_id == admin_id:
        raise HTTPException(409, 'CANNOT_CHANGE_OWN_ROLE')
    # 같은 회원의 역할을 동시에 바꾸는 요청을 직렬화한다.
    user = db.scalar(select(User).where(User.id == user_id).with_for_update())
    if user is None:
        raise HTTPException(404, 'USER_NOT_FOUND')
    user.role = data.role
    db.commit()
    accounts = db.scalars(select(SocialAccount).where(SocialAccount.user_id == user.id)).all()
    return to_out(user, list(accounts))
