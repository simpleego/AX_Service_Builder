import os, secrets, hashlib, hmac, base64, uuid
from datetime import datetime, timedelta, timezone
import jwt
from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy import select
from sqlalchemy.orm import Session
from .database import get_db
from .models import RefreshToken, User
SECRET = os.getenv('JWT_SECRET', '')
if len(SECRET.encode()) < 32:
    raise RuntimeError('JWT_SECRET에 무작위 32바이트 이상의 비밀값을 지정하세요.')
ISSUER, AUDIENCE = 'todo-api', 'todo-client'
def now():
    """현재 UTC 시각. 만료 시각(expires_at) 저장·비교에 공통으로 쓴다.

    MySQL DATETIME은 timezone 정보가 없으므로 UTC naive datetime으로 통일한다.
    """
    return datetime.now(timezone.utc).replace(tzinfo=None)
def digest(value: str):
    """문자열의 SHA-256 16진수 해시(64자).

    소셜 로그인의 state·binding, React 일회용 코드, refresh 토큰처럼
    '원문을 알면 바로 쓸 수 있는 값'은 DB에 이 해시만 저장한다. DB가 유출돼도 원문을 재사용할 수 없다.
    """
    return hashlib.sha256(value.encode()).hexdigest()
def password_hash(password: str, salt: str | None = None):
    salt = salt or secrets.token_hex(16)
    # 사용자별 salt와 scrypt로 비밀번호를 단방향 해시한다. DB에는 평문을 저장하지 않는다.
    hashed = hashlib.scrypt(password.encode(), salt=salt.encode(), n=16384, r=8, p=1, dklen=64)
    return salt + ':' + hashed.hex()
def password_matches(password, stored):
    return bool(stored) and hmac.compare_digest(password_hash(password, stored.split(':')[0]), stored)
def issue_tokens(db, user_id: int, family: str | None = None, expires: datetime | None = None):
    """앱 토큰 쌍(access JWT + opaque refresh)을 발급한다.

    로컬 로그인, Google 콜백(JSON 모드), React 일회용 코드 교환이 모두 이 함수를 쓴다.
    즉 소셜 로그인도 일단 끝나면 Google 토큰이 아니라 이 앱의 토큰으로 API를 호출한다.
    - family  : 같은 로그인 세션에서 회전된 refresh 토큰 묶음 id. None이면 새 세션.
    - expires : refresh 절대 만료 시각. None이면 지금부터 7일(회전 때는 기존 값을 넘겨 연장하지 않음).
    refresh 행은 db.add만 하고 commit은 호출한 쪽이 한다.
    """
    stamp = now()
    access = jwt.encode({'sub': str(user_id), 'type': 'access', 'iss': ISSUER, 'aud': AUDIENCE,
        'iat': stamp.replace(tzinfo=timezone.utc), 'exp': (stamp+timedelta(minutes=15)).replace(tzinfo=timezone.utc)}, SECRET, algorithm='HS256')
    refresh = secrets.token_urlsafe(32)
    # opaque refresh token은 256비트 무작위 값이며 SHA-256 해시만 DB에 보관한다.
    db.add(RefreshToken(token_hash=digest(refresh), user_id=user_id, family_id=family or str(uuid.uuid4()),
        expires_at=expires or stamp+timedelta(days=7)))
    return {'accessToken': access, 'refreshToken': refresh, 'tokenType': 'Bearer', 'expiresIn': 900}
bearer = HTTPBearer(auto_error=False)
def current_user(credentials: HTTPAuthorizationCredentials | None = Depends(bearer)):
    """Authorization: Bearer <access JWT>를 검증하고 사용자 id(int)를 돌려주는 FastAPI 의존성.

    로컬 회원과 Google 회원을 구분하지 않는다(둘 다 issue_tokens로 받은 같은 형식의 토큰).
    검증에 실패하면 401 UNAUTHORIZED.
    """
    try:
        if credentials is None:
            raise ValueError('missing bearer')
        # 서명뿐 아니라 알고리즘/issuer/audience/필수 claim/만료/토큰 종류까지 검증한다.
        payload = jwt.decode(credentials.credentials, SECRET, algorithms=['HS256'], issuer=ISSUER,
            audience=AUDIENCE, options={'require': ['exp', 'iat', 'sub', 'iss', 'aud', 'type']})
        if payload['type'] != 'access' or not payload['sub'].isdigit() or not 0 < int(payload['sub']) <= 4294967295:
            raise ValueError('invalid subject/type')
        return int(payload['sub'])
    except (jwt.PyJWTError, ValueError, KeyError, TypeError, AttributeError):
        raise HTTPException(401, 'UNAUTHORIZED', headers={'WWW-Authenticate': 'Bearer'})
# ── 인가(Authorization) ────────────────────────────────────────────────
# 인증(current_user)은 "누구인가"를 확인하고(실패 시 401), 인가(require_role)는
# "그 사람이 이 일을 해도 되는가"를 확인한다(실패 시 403).
ROLES = ('user', 'admin')
def require_role(*allowed: str):
    """지정한 역할 중 하나를 가진 사용자만 통과시키는 FastAPI 의존성을 만든다.

    사용 예: `admin_id: int = Depends(require_role('admin'))`
    - 토큰이 없거나 잘못됨        → current_user가 401 UNAUTHORIZED
    - 토큰은 맞지만 역할이 다름    → 403 FORBIDDEN
    역할은 JWT에 넣지 않고 매 요청마다 DB에서 읽는다. 그래서 관리자가 역할을 바꾸거나
    빼앗으면 이미 발급된 토큰에도 즉시 반영된다(대신 요청마다 조회 1회가 추가됨).
    로컬 회원과 Google 회원을 구분하지 않는다. 둘 다 같은 users 행의 role을 본다.
    """
    unknown = set(allowed) - set(ROLES)
    if unknown:
        raise ValueError(f'알 수 없는 역할: {unknown}')
    def checker(user_id: int = Depends(current_user), db: Session = Depends(get_db)) -> int:
        role = db.scalar(select(User.role).where(User.id == user_id))
        if role is None:
            # 토큰은 유효하지만 회원이 삭제된 경우: 인증 실패로 본다.
            raise HTTPException(401, 'UNAUTHORIZED', headers={'WWW-Authenticate': 'Bearer'})
        if role not in allowed:
            raise HTTPException(403, 'FORBIDDEN')
        return user_id
    return checker
